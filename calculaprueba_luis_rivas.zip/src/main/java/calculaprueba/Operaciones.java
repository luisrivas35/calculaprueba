package calculaprueba;

public class Operaciones {
	public boolean esPar(int num) {
		return num % 2 == 0;
	  
	}
	
	public long promedio (int num1, int num2, int num3) {
		long prom = (num1+ num2 + num3) / 3;
		return prom;
	
	}

}
